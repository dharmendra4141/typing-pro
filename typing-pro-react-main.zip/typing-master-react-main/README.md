# Typing Pro

This is `Typing Master` is a website Where we can practice our typing, We can measure typing speed, acuracy and WPM. It has `light` and `dark` theme.

# Installation

```bash
git clone https://github.com/satyamgcode/typing-pro

cd typing-pro

# Install Dependencies
npm install

# Now we can run development server 
npm run dev

# Tech Stack

- __ReactJs__
- __React Redux__
- __React Router Dom__
- __ChartJs__
- __Firebase__


